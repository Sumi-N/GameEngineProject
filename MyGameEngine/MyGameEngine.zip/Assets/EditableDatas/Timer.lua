Object3D = {
    name = "Timer",
    initial_position = { -1000, -1000, 0},
    initial_rotation = { 0, 0, 0},

    Physics2D_settings = {
        mass = 1.0,
        air_friction = 0,
        velocity = {0, 0, 0},
        accelaration = {0, 0, 0}
    },

    SpriteRender_settings = {
        path = ""
    },
}