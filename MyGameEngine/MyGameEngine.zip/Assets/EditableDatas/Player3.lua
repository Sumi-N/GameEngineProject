Object3D = {
    name = "ThirdGuy",
    initial_position = { -210, -100, 0},
    initial_rotation = { 0, 0, 0},

    Physics2D_settings = {
        mass = 1.0,
        air_friction = 0.00,
        velocity = {0.1, 0, 0},
        accelaration = {0, 0, 0}
    },

    SpriteRender_settings = {
        path = "..\\Assets\\data\\GoodGuy.dds"
    },
}