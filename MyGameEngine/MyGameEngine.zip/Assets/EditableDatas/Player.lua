Player =
{
    name = "Joe",
    class = "Player",
    controller = "InputController",
    initial_position = { 9.0, 2.5, 3.0},

    bounding_box = {
        offset = {0.0, 0.0, 0.0},
        size = {10.0, 10.0, 10.0}
    }
}