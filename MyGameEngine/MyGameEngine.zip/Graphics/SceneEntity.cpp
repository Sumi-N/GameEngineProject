#pragma once

#include "SceneEntity.h"

std::vector<SceneFormat> SceneEntity::List;
CubeMapFormat SceneEntity::SkyBoxScene;