#pragma once

#include "Messenger.h"

Engine::MultiCastDelegate<int> * System::Messenger::LogMessenger;