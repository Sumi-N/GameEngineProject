#pragma once

#include "Define.h"

class Attribute
{
public:
	
};
